using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Checkers : MonoBehaviour
{
    void Start()
    {
        Debug.Log("Persistent Data Path: " + Application.persistentDataPath);
    }
}

