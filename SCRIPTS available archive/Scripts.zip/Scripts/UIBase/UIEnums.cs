using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MyGameProject
{
    public enum Clicked
    {
        ON,
        OFF,
    }
    public enum ActiveState
    {  
        WAITING,
        OFF,
        ON
    }

}