using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace MyGameProject
{
    public class Enemy : Character
    {
        private NavMeshAgent agent; 
        private Transform target;
        private Animator animator;
        private Collider attackZoneCollider;
        private EnemyController enemyController;
        [SerializeField] private float attackDamage;

        public NavMeshAgent Agent
        {
            get { return agent; }
            set { agent = value; }
        }

        public Transform Target
        {
            get { return target; }
            set { target = value; }
        }

        public Animator Animator
        {
            get { return animator; }
            set { animator = value; }
        }

        public float MaxHealth
        {
            get { return maxHealth; }
            set { maxHealth = value; } 
        }
        

        private void Awake()
        {
            Agent = GetComponent<NavMeshAgent>();
            Target = FindObjectOfType<Player>().transform;
            Animator = GetComponent<Animator>();
            enemyController = GetComponent<EnemyController>();
            CurrentHealth = MaxHealth;
            AttackZoneFinder();
        }

        private void AttackZoneFinder()
        {
            GameObject attackZoneObject = GameObject.FindWithTag("AttackZone");

            if (attackZoneObject != null)
            {
                attackZoneCollider = attackZoneObject.GetComponent<Collider>();

                if (attackZoneCollider != null)
                {
                    Debug.Log("��������� AttackZone ������ ����� ���!");
                }
                else
                {
                    Debug.LogError("�� ������� AttackZone ��� ����������!");
                }
            }
            else
            {
                Debug.LogError("������ � ����� AttackZone �� ������!");
            }
        }

        private void Update()
        {
        }

       

        public override void Heal(float healingAmount)
        {

        }

        public override void TakeDamage(float damage)
        {
            CurrentHealth -= damage;
            CheckHealth();
            enemyController.TakeDamage();
        }

        public override void UpdateState()
        {
            if (CurrentHealth == 0)
            {
                StateSetGet = State.DEAD;
            }
            else if (CurrentHealth > 0)
            {
                StateSetGet = State.INGAME;
            }
        }

        public float GetDamageForAttack()
        {
            return attackDamage;
        }
    }
}
