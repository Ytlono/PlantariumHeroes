using UnityEngine;

namespace MyGameProject
{
    public class EnemyAttackZoneController : MonoBehaviour
    {
        private EnemyController enemyController;
        private Collider attackZoneCollider;
        private void Awake()
        {
            enemyController = GetComponentInParent<EnemyController>();
            attackZoneCollider = GetComponent<Collider>();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!enemyController.Enemy.IsAlive()) { 
                attackZoneCollider.enabled = false; 
                return; 
            }

            if (other.CompareTag("Player"))
            {
                enemyController.SetPlayerInAttackZone(true);
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                enemyController.SetPlayerInAttackZone(false);
            }
        }
    }
}
