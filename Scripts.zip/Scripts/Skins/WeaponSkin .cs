﻿using System;
using UnityEngine;

namespace MyGameProject
{
    public class WeaponSkin : Skin
    {
        public WeaponSkin(SkinData skinData)
        {
            Name = skinData.Name;
            Description = skinData.Description;
            RarityLevel = skinData.GetRarityLevel();
            Price = skinData.Price;
            DropChance = skinData.DropChance;
            Access = skinData.GetAccess();
            SkinSpritePath = skinData.SkinSprite;
        }

        public string SkinSpritePath { get; private set; } // Путь к спрайту

        public override void CountingPrice()
        {
            int basePrice = 50;
            Price = basePrice * (int)RarityLevel;
        }

        public override void ApplyEffect()
        {
            // Находим оружие игрока (по тегу или другому способу)
            GameObject weapon = GameObject.FindWithTag("Weapon");
            if (weapon != null)
            {
                Renderer weaponRenderer = weapon.GetComponent<Renderer>();
                if (weaponRenderer != null && SkinSprite != null)
                {
                    weaponRenderer.material.mainTexture = SkinSprite.texture;
                }
            }
            else
            {
                Debug.LogError("Weapon object not found. Make sure it has the correct tag or reference.");
            }
        }

        public override void DisplayInfo()
        {
            Debug.Log($"Name: {Name}, Rarity: {RarityLevel}, Price: {Price}, Description: {Description}");
        }

        public override string ToString()
        {
            return $"Name: {Name}\nDescription: {Description}\nRarity: {RarityLevel}\nPrice: {Price}\nDrop Chance: {DropChance}\nAccess: {Access}\nSpritePath: {SkinSpritePath}";
        }

        // Метод для загрузки спрайта
        public void LoadSprite()
        {
            if (!string.IsNullOrEmpty(SkinSpritePath))
            {
                // Путь к спрайту относительно папки Resources
                SkinSprite = Resources.Load<Sprite>(SkinSpritePath);

                if (SkinSprite == null)
                {
                    Debug.LogError($"Sprite not found at path: {SkinSpritePath}. Check if the path is correct and the sprite is in Resources.");
                }
            }
            else
            {
                Debug.LogWarning("SkinSpritePath is empty. Cannot load sprite.");
            }
        }
    }
}
