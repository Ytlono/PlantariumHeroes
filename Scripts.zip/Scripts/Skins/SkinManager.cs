using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

namespace MyGameProject
{
    public class SkinManager : MonoBehaviour
    {
        private List<PlayerSkin> playerSkins;
        private List<WeaponSkin> weaponSkins;
        private List<Skin> allSkins; // ����� ��������� ��� ���� ����� ������

        private List<PlayerSkin> PlayerSkinList
        {
            get { return playerSkins; }
            set { playerSkins = value; }
        }
        private Player Player { get; set; }
        private Weapon Weapon { get; set; } 
        private void Awake()
        {
            Player = FindAnyObjectByType<Player>();
            Weapon = FindAnyObjectByType<Weapon>();
            PlayerSkinList = new List<PlayerSkin>();
            weaponSkins = new List<WeaponSkin>();
            allSkins = new List<Skin>();

            LoadSkinsFromJson("GamePrefabs/Skins/PlayerSkinsData", typeof(PlayerSkin));
            LoadSkinsFromJson("GamePrefabs/Skins/WeaponSkins/WeaponSkinsData", typeof(WeaponSkin));

            if (allSkins.Count > 0)
            {
                LoadSpritesForSkins();
                DisplayAllSkinsInfo();
            }
            else
            {
                Debug.LogError("No skins loaded. Check the JSON files or paths.");
            }
        }

        private void LoadSkinsFromJson(string fileName, Type skinType)
        {
            TextAsset jsonFile = Resources.Load<TextAsset>(fileName);
            if (jsonFile == null)
            {
                Debug.LogError($"JSON file not found at path: {fileName}");
                return;
            }

            try
            {
                string json = jsonFile.text;
                SkinDataList skinDataList = JsonUtility.FromJson<SkinDataList>(json);

                if (skinDataList == null || skinDataList.skins.Count == 0)
                {
                    Debug.LogWarning($"No skins found in the JSON file: {fileName}");
                    return;
                }

                foreach (var skinData in skinDataList.skins)
                {
                    if (skinType == typeof(PlayerSkin))
                    {
                        PlayerSkin skin = new PlayerSkin(skinData);
                        PlayerSkinList.Add(skin);
                        allSkins.Add(skin);
                    }
                    else if (skinType == typeof(WeaponSkin))
                    {
                        WeaponSkin skin = new WeaponSkin(skinData);
                        weaponSkins.Add(skin);
                        allSkins.Add(skin);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"Error parsing JSON: {ex.Message}");
            }
        }

        private void LoadSpritesForSkins()
        {
            foreach (var skin in allSkins)
            {
                if (skin is PlayerSkin playerSkin)
                {
                    playerSkin.LoadSprite();
                }
                else if (skin is WeaponSkin weaponSkin)
                {
                    weaponSkin.LoadSprite();
                }
            }
        }

        private void DisplayAllSkinsInfo()
        {
            if (allSkins.Count == 0)
            {
                Debug.Log("No skins available.");
                return;
            }

            Debug.Log("Available Skins:");
            foreach (var skin in allSkins)
            {
                Debug.Log(skin.ToString());
            }
        }

        public ReadOnlyCollection<PlayerSkin> GetPlayerSkins()
        {
            return PlayerSkinList.AsReadOnly();
        }

        public ReadOnlyCollection<WeaponSkin> GetWeaponSkins()
        {
            return weaponSkins.AsReadOnly();
        }

        public void UnlockSkin(Skin skin)
        {
            if (skin != null)
            {
                Debug.Log($"Unlock skin {skin.Name}");
            }
            else
            {
                Debug.Log($"NULLLLLLL");
            }
            if (Player.MakePurchase(skin.Price))
            {
                skin.Access = Accesses.UNLOCKED;
                if (skin.Access == Accesses.UNLOCKED)
                {
                    Debug.Log("SUCSESFULL PURCHASE");
                }
            }
            else
            {
                Debug.Log("DECLINE");
            }

        }
        public void ApplySkin(Skin skin)
        {
            if (skin is PlayerSkin playerSkin)
            {
                ApplyPlayerSkin(playerSkin.SkinSprite);
            }
            else if (skin is WeaponSkin weaponSkin)
            {
                ApplyWeaponSkin(weaponSkin.SkinSprite);
            }
        }

        public void ApplyPlayerSkin(Sprite skinSprite)
        {
            Player.ChangePlayerSkin(skinSprite);
            if (skinSprite == null)
            {
                Debug.Log($"��������");
                // �������� ������ ���������� ���������� �����
            }
        }

        public void ApplyWeaponSkin(Sprite skinSprite)
        {
            Weapon.ChangeWeaponSkin(skinSprite);
            if (skinSprite == null)
            {
                Debug.Log($"�������");
                // �������� ������ ���������� ���������� �����
            }
        }
    }
}
