﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace MyGameProject
{
    public class PlayerSkin : Skin
    {
        public PlayerSkin(SkinData skinData)
        {
            Name = skinData.Name;
            Description = skinData.Description;
            RarityLevel = skinData.GetRarityLevel();
            Price = skinData.Price;
            DropChance = skinData.DropChance;
            Access = skinData.GetAccess();
            SkinSpritePath = skinData.SkinSprite;
        }


        public string SkinSpritePath { get; private set; } // Путь к спрайту

        public override void CountingPrice()
        {
            int basePrice = 100;
            Price = basePrice * (int)RarityLevel;
        }

        public override void ApplyEffect()
        {
            Renderer playerRenderer = GameObject.FindWithTag("Player").GetComponent<Renderer>();
            if (playerRenderer != null && SkinSprite != null)
            {
                playerRenderer.material.mainTexture = SkinSprite.texture;
            }
        }

        public override void DisplayInfo()
        {
            Debug.Log($"Name: {Name}, Rarity: {RarityLevel}, Price: {Price}, Description: {Description}");
        }

        public override string ToString()
        {
            return $"Name: {Name}\nDescription: {Description}\nRarity: {RarityLevel}\nPrice: {Price}\nDrop Chance: {DropChance}\nAccess: {Access}\nSpritePath: {SkinSpritePath}";
        }

        // Метод для загрузки спрайта
        public void LoadSprite()
        {
            if (!string.IsNullOrEmpty(SkinSpritePath))
            {
                // Путь к спрайту относительно папки Resources
                SkinSprite = Resources.Load<Sprite>(SkinSpritePath);

                if (SkinSprite == null)
                {
                    Debug.LogError($"Sprite not found at path: {SkinSpritePath}. Check if the path is correct and the sprite is in Resources.");
                }
            }
            else
            {
                Debug.LogWarning("SkinSpritePath is empty. Cannot load sprite.");
            }
        }


        public SkinData ToSkinData()
        {
            return new SkinData
            {
                Price = this.Price,
                Name = this.Name,
                Description = this.Description,
                RarityLevel = this.RarityLevel.ToString(), // Явное преобразование в строку
                DropChance = this.DropChance,
                Access = this.Access.ToString(),          // Явное преобразование в строку
                SkinSprite = this.SkinSpritePath
            };
        }

    }

    [System.Serializable]
    public class SkinData
    {
        public int Price;
        public string Name;
        public string Description;
        public string RarityLevel; // Теперь это string
        public float DropChance;
        public string Access;      // Теперь это string
        public string SkinSprite;

        public Rarity GetRarityLevel()
        {
            if (Enum.TryParse<Rarity>(RarityLevel, true, out var parsedRarity))
            {
                return parsedRarity;
            }
            Debug.LogError($"Invalid rarity level: {RarityLevel}");
            return Rarity.COMMON; 
        }

        public Accesses GetAccess()
        {
            if (Enum.TryParse<Accesses>(Access, true, out var parsedAccess))
            {
                return parsedAccess;
            }
            Debug.LogError($"Invalid access level: {Access}");
            return Accesses.LOCKED; 
        }
    }


    [System.Serializable]
    public class SkinDataList
    {
        public List<SkinData> skins = new List<SkinData>();
    }
}
