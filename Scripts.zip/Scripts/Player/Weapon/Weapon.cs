﻿using UnityEngine;

namespace MyGameProject
{
    public class Weapon : MonoBehaviour
    {
        [SerializeField]
        private float damage = 30f;
        [SerializeField]
        private Material weaponMaterial;

        public void ChangeWeaponSkin(Sprite skin)
        {
            if (weaponMaterial == null)
            {
                Debug.LogError("Weapon material is not assigned.");
                return;
            }

            if (skin == null)
            {
                Debug.LogError("Skin sprite is not assigned.");
                return;
            }
            // Устанавливаем основную текстуру
            weaponMaterial.mainTexture = skin.texture;

            // Включаем эмиссию, если она еще не включена
            weaponMaterial.EnableKeyword("_EMISSION");

            // Устанавливаем эмиссию текстуры (на основе спрайта)
            weaponMaterial.SetTexture("_EmissionMap", skin.texture);

            // Настроим цвет эмиссии, чтобы она была яркой (можно менять интенсивность)
            weaponMaterial.SetColor("_EmissionColor", Color.white * 2f); // Увеличиваем яркость
        }

        public float Damage
        {
            get { return damage; }
            private set { damage = value; }
        }

        public void UpgradeDamage(float addDamage)
        {
            Damage += addDamage;
        }
    }
}
