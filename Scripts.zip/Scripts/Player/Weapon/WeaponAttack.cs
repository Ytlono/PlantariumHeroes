using MyGameProject;
using System.Collections.Generic;
using UnityEngine;

namespace MyGameProject
{
    public class WeaponAttack : MonoBehaviour
    {
        private Collider weaponCollider;
        private List<Collider> damagedEnemies = new List<Collider>();

        [SerializeField]
        private Weapon weapon; // ������ �� ������ Weapon � �����

        void Start()
        {
            weaponCollider = GetComponent<Collider>();

            if (weaponCollider != null)
            {
                weaponCollider.isTrigger = true;
                weaponCollider.enabled = false;
            }

            // ���������, ���� Weapon �� �������� ����� ���������
            if (weapon == null)
            {
                weapon = FindObjectOfType<Weapon>();
                if (weapon == null)
                {
                    Debug.LogError("Weapon not assigned or found!");
                }
            }
        }

        public void IsEnableWeaponCollider(bool isEnable)
        {
            if (weaponCollider != null)
            {
                weaponCollider.enabled = isEnable;
            }
        }

        private void OnTriggerEnter(Collider other)
        {
            if (other.isTrigger)
                return;

            if (other.gameObject.layer == LayerMask.NameToLayer("Enemy") && !damagedEnemies.Contains(other))
            {
                Enemy enemy = other.GetComponent<Enemy>();
                if (enemy != null)
                {
                    // ���������� ������� �������� Damage �� Weapon
                    float damageAmount = weapon.Damage;
                    enemy.TakeDamage(damageAmount);

                    damagedEnemies.Add(other);

                    Player player = FindObjectOfType<Player>();
                    if (player != null)
                    {
                        player.IncreaseManna(damageAmount * 0.5f);
                    }
                }
            }
        }

        public void ResetDamageEnemies()
        {
            damagedEnemies.Clear();
        }

        public float GetDamageAmount()
        {
            // ���������� ������� �������� Damage �� Weapon
            return weapon != null ? weapon.Damage : 0f;
        }
    }
}
