using UnityEngine;
using UnityEngine.EventSystems;

namespace MyGameProject
{
    public class PlayerController : MonoBehaviour
    {
        private PlayerRun playerRun;
        private PlayerJump playerJump;
        private PlayerDie playerDie;
        private PlayerAttack playerAttack;
        private Player player;
        private bool isAttacking;
        private bool isHoldingAttack;

        void Start()
        {
            playerRun = GetComponent<PlayerRun>();
            playerJump = GetComponent<PlayerJump>();
            playerDie = GetComponent<PlayerDie>();
            playerAttack = GetComponent<PlayerAttack>();
            player = GetComponent<Player>();
        }

        void Update()
        {
            if (!isAttacking && player.IsAlive())
            {
                HandleRunInput();
                HandleJumpInput();
            }

            HandleDeathAndRecovery();
            AttackCombinations();
        }

        private void HandleRunInput()
        {
            if (!isAttacking && player.IsAlive())
            {
                playerRun.Run();
            }
            else
            {
                playerRun.SetSpeedToBlendTree(0f);
            }
        }

        private void HandleJumpInput()
        {
        }

        private void HandleDeathAndRecovery()
        {
            if (!player.IsAlive())
            {
                playerRun.StopMovement();
                playerDie.ActivateDieAnimation();
                isAttacking = false;
            }

            if (!player.IsAlive() && Input.GetKeyDown(KeyCode.C))
            {
                player.Heal(100f);
                playerDie.ActivateDieRecoveryAnimation();
            }
        }

        private void AttackCombinations()
        {
            if (Input.GetMouseButtonDown(0) && player.IsAlive() && !IsPointerOverUI())
            {
                isAttacking = true;
                isHoldingAttack = true;
                playerRun.StopMovement();
                playerAttack.Attack1(isAttacking);
            }
            if (player.IsManaFull() && Input.GetKey(KeyCode.Q))
            {
                player.IncreaseManna(-100);
            }

            if (Input.GetMouseButton(0) && isHoldingAttack && player.IsAlive())
            {
                playerAttack.Attack1(true);
            }
             
            if (playerAttack.CheckEndOfAnimation() && !Input.GetMouseButton(0))
            {
                isAttacking = false;
                isHoldingAttack = false;
                playerAttack.Attack1(false);
            }
        }

        private bool IsPointerOverUI()
        {
            return EventSystem.current.IsPointerOverGameObject();
        }
    }
}
