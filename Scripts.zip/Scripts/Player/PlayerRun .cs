﻿using UnityEngine;

namespace MyGameProject
{
    public class PlayerRun : MonoBehaviour
    {
        private Animator animator;
        private Rigidbody rigidBody;

        [SerializeField]
        private float speed = 4f;

        [SerializeField]
        private float rotationSpeed = 20f;

        [SerializeField]
        private Transform cameraTransform;

        public float Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public float RotationSpeed
        {
            get { return rotationSpeed; }
            set { rotationSpeed = value; }
        }

        void Awake()
        {
            rigidBody = GetComponent<Rigidbody>();
            animator = GetComponent<Animator>();
        }

        public void Run()
        {
            float horizontal = Input.GetAxis("Horizontal");
            float vertical = Input.GetAxis("Vertical");

            Vector3 inputDirection = new Vector3(horizontal, 0, vertical);

            if (inputDirection != Vector3.zero)
            {
                MoveCharacter(inputDirection);
            }
            else
            {
                StopMovement();
            }
        }

        private void MoveCharacter(Vector3 inputDirection)
        {
            Vector3 forward = cameraTransform.forward;
            Vector3 right = cameraTransform.right;

            forward.y = 0;
            right.y = 0;

            forward.Normalize();
            right.Normalize();

            Vector3 moveDirection = (forward * inputDirection.z + right * inputDirection.x).normalized;

            RotateCharacter(moveDirection);

            Vector3 clampedDirection = Vector3.ClampMagnitude(moveDirection, 1);

            float movementSpeed = clampedDirection.magnitude * Speed;

            UpdateAnimation(movementSpeed);

            ApplyMovement(clampedDirection, movementSpeed);
        }

        private void RotateCharacter(Vector3 moveDirection)
        {
            transform.rotation = Quaternion.Lerp(
                transform.rotation,
                Quaternion.LookRotation(moveDirection),
                Time.deltaTime * rotationSpeed
            );
        }

        private void UpdateAnimation(float movementSpeed)
        {
            animator.SetBool("IsWalk", movementSpeed > 0.1f);
            SetSpeedToBlendTree(movementSpeed);
        }

        private void ApplyMovement(Vector3 clampedDirection, float movementSpeed)
        {
            Vector3 newVelocity = clampedDirection * Speed;
            newVelocity.y = rigidBody.velocity.y;
            rigidBody.velocity = newVelocity;
        }

        public void SetSpeedToBlendTree(float movementSpeed)
        {
            animator.SetFloat("speed", movementSpeed);
        }

        public void StopMovement()
        {
            Vector3 currentVelocity = rigidBody.velocity;
            rigidBody.velocity = new Vector3(0, currentVelocity.y, 0);

            animator.SetBool("IsWalk", false);
            SetSpeedToBlendTree(0f);
        }

    }
}
