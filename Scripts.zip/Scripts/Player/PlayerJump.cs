﻿using UnityEngine;

namespace MyGameProject
{
    public class PlayerJump : MonoBehaviour
    {
    }
}
