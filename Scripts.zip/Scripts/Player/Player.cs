using UnityEngine;

namespace MyGameProject
{
    public class Player : Character
    {
        [SerializeField]
        private float currentManna;
        private float maxManna = 100f;
        [SerializeField]
        private int money = 1000;

        private Weapon weapon;
        public HealthBar healthBar;
        public ManaBar manaBar;
        [SerializeField]
        private PlayerMoney playerMoney;

        [SerializeField]
        private Material PlayerMaterial;

        private float CurrentManna
        {
            set
            {
                if (value <= 0f)
                {
                    currentManna = 0f;
                }
                else if (currentManna > maxManna)
                {
                    currentManna = maxManna;
                }
                else
                {
                    currentManna = value;
                }
            }
            get { return currentManna; }
        }

        public int Money
        {
            get { return money; }
            set { money = value; }
        }

        private void Awake()
        {
            weapon = new Weapon();
            healthBar = FindObjectOfType<HealthBar>();
            manaBar = FindObjectOfType<ManaBar>();
            playerMoney = FindObjectOfType<PlayerMoney>();
            CurrentManna = maxManna;
            Money = 6000;
        }

        private void Update()
        {
            healthBar.UpdateHealthBar(CurrentHealth, maxHealth);
            manaBar.UpdateManaBar(CurrentManna, maxManna);
            playerMoney.UpdateBalance(Money);
            if (Input.GetKeyDown(KeyCode.H))
            {
                TakeDamage(10f);
            }

            UpdateState();
        }

        public bool MakePurchase(int price)
        {
            if (price < 0)
            {
                Debug.Log("���� �� ����� ���� �������������");
                return false;
            }

            if (Money < price)
            {
                Debug.Log("������������ �������");
                return false;
            }

            Money -= price;
            Debug.Log("������� �������!");
            return true;
        }

        public void IncreaseManna(float amount)
        {
            CurrentManna += amount;
        }

        public bool IsManaFull()
        {
            return CurrentManna == 100;
        }

        public override void Heal(float healingAmount)
        {
            CurrentHealth += healingAmount;
        }

        public override void TakeDamage(float damage)
        {
            CurrentHealth -= damage;
            CheckHealth();
        }

        public override void UpdateState()
        {
            if (CurrentHealth == 0)
            {
                StateSetGet = State.DEAD;
            }
            else if (CurrentHealth > 0)
            {
                StateSetGet = State.INGAME;
            }
        }

        public void ChangePlayerSkin(Sprite skin)
        {
            PlayerMaterial.mainTexture = skin.texture;
        }

        public void UpgradePlayerHealth(float addHealth)
        {
            maxHealth += addHealth;
        }
    }
}
