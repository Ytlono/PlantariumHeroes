using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace MyGameProject
{
    public class HeartImage : MonoBehaviour
    {
        [SerializeField]
        private Image heart;

        [SerializeField]
        private float beatDuration = 0.2f; // ������������ ������ ������
        [SerializeField]
        private float minScale = 0.8f; // ����������� ������
        [SerializeField]
        private float maxScale = 1.2f; // ������������ ������

        void Start()
        {
            StartCoroutine(BeatHeart());
        }

        private IEnumerator BeatHeart()
        {
            while (true)
            {
                yield return StartCoroutine(ScaleHeart(maxScale));
                yield return StartCoroutine(ScaleHeart(minScale));
            }
        }

        private IEnumerator ScaleHeart(float targetScale)
        {
            float currentTime = 0f;
            Vector3 initialScale = heart.transform.localScale;
            Vector3 targetScaleVector = new Vector3(targetScale, targetScale, 1);

            while (currentTime < beatDuration)
            {
                currentTime += Time.deltaTime;
                heart.transform.localScale = Vector3.Lerp(initialScale, targetScaleVector, currentTime / beatDuration);
                yield return null;
            }

            heart.transform.localScale = targetScaleVector;
        }
    }
}