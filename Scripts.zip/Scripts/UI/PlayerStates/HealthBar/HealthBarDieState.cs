using UnityEngine;
using UnityEngine.UI;

namespace MyGameProject
{
    public class HealthBarDieState : MonoBehaviour
    {
        private Player player;

        public void HideAndShowComponents(bool isEnable)
        {
            foreach (Transform child in transform)
            {
                Image image = child.GetComponent<Image>();
                if (image != null)
                {
                    image.enabled = isEnable;
                }

                Button button = child.GetComponent<Button>();
                if (button != null)
                {
                    button.enabled = isEnable;

                    // ������� ������ ������ ������
                    Text buttonText = button.GetComponentInChildren<Text>();
                    if (buttonText != null)
                    {
                        buttonText.enabled = isEnable;
                    }
                }

            }
        }

        void Start()
        {
            player = FindObjectOfType<Player>();
            HideAndShowComponents(false);
        }

        void Update()
        {
            if (player.StateSetGet == State.DEAD)
            {
                HideAndShowComponents(true);
            }
            if (player.StateSetGet == State.INGAME)
            {
                HideAndShowComponents(false);
            }
        }
    }
}
