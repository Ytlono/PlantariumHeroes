using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MyGameProject
{
    public class QuickMenuButtons : MonoBehaviour
    {
        [SerializeField] private Button volumeButton;
        private Clicked clickedVolumeButton;
        private MainMenu mainMenu;
        StopGame stopGame;
        private void Awake()
        {
            clickedVolumeButton = Clicked.OFF;
            mainMenu = FindAnyObjectByType<MainMenu>(); // ������ �� MainMenu
            stopGame = FindAnyObjectByType<StopGame>();
        }

        public void OnClickPauseButton()
        {
            stopGame.StopGameProcesses(true);
            mainMenu.ToggleMenu();
        }

        public void OnClickVolumeButton()
        {
            if (!IsClick(clickedVolumeButton))
            {
                Debug.Log("PRESSED");
                volumeButton.image.color = Color.grey;
                clickedVolumeButton = Clicked.ON;
            }
            else
            {
                Debug.Log("NOTPRESSED");
                volumeButton.image.color = Color.white;
                clickedVolumeButton = Clicked.OFF;
            }
        }

        private bool IsClick(Clicked buttonClick)
        {
            return buttonClick == Clicked.ON;
        }
    }
}
