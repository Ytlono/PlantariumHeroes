using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MyGameProject
{
    public class ShopPanel : MonoBehaviour
    {
        [SerializeField]
        private GameObject shopPanel;

        private ActiveState shopState;
        [SerializeField]
        private GameObject skinShop;
        [SerializeField]
        private GameObject upgradeShop;

        private void Start()
        {
            shopPanel.SetActive(false);
            shopState = ActiveState.OFF;
        }

        public void ToggleShopPanel()
        {
            if (!IsShopActive())
            {
                SetShopActive(true);
                shopState = ActiveState.ON;
                Debug.Log("Menu turned ON");
            }
            else
            {
                SetShopActive(false);
                shopState = ActiveState.OFF;
                Debug.Log("Menu turned OFF");
            }
        }

        public bool IsShopActive()
        {
            return shopState == ActiveState.ON;
        }

        public void SetShopActive(bool isActive)
        {
            shopPanel.SetActive(isActive);
        }

        private void SwitchToSkinShop()
        {
            upgradeShop.SetActive(false);
            skinShop.SetActive(true);
        }
        
        private void SwitchToUpgradeShop()
        {
            skinShop.SetActive(false);
            upgradeShop.SetActive(true);
        }

        public void OnClickUpgradeButton()
        {
            SwitchToUpgradeShop();
        }
        public void OnClickSkinsButton()
        {
            SwitchToSkinShop();
        }

    }
}