using MyGameProject;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MyGameProject
{
    public class MainMenu : MonoBehaviour
    {
        [SerializeField] 
        private GameObject mainMenu;
        private ActiveState menuState;
        private MainMenuButtons mainMenuButtons;
        private ShopPanel shopPanel;
        StopGame stopGame;

        public ActiveState MenuState
        {
            get { return menuState; }
            private set { menuState = value; }
        }

        private void Awake()
        {
            mainMenuButtons = FindAnyObjectByType<MainMenuButtons>();
            shopPanel = FindAnyObjectByType<ShopPanel>();
            stopGame = FindAnyObjectByType<StopGame>();
            if (mainMenuButtons != null)
            {
                Debug.Log("PIIIIIZFDA");
            }
            mainMenu.SetActive(false);
            menuState = ActiveState.OFF;
        }

        public void ToggleMenu()
        {
            // ������ ������������ ��������� ����
            if (!IsMenuActive())
            {
                SetMenuActive(true);
                menuState = ActiveState.ON;
                Debug.Log("Menu turned ON");
            }
            else
            {
                SetMenuActive(false);
                menuState = ActiveState.OFF;
                Debug.Log("Menu turned OFF");
            }
        }

        public void SetMenuActive(bool isActive)
        {
            mainMenu.SetActive(isActive);
        }

        public bool IsMenuActive()
        {
            return menuState == ActiveState.ON;
        }

        public void OnClickResumeButton()
        {
            stopGame.StopGameProcesses(false);
            ToggleMenu();
        }

        public void OnClickExitButton()
        {
            // �������� ����, ���� ������� �� �����
            SetMenuActive(false);
            mainMenuButtons.confirmExitPanel.SetActive(true); // ���������� ������ ������������� ������
        }

        public void OnClickShopButton()
        {
            shopPanel.SetShopActive(true);
        }

        public void OnClickShopButtonReturn()
        {
            shopPanel.SetShopActive(false);
            SetMenuActive(true);
        }

        public void RestoreMenuButtons()
        {
            // ��������������� ������
            foreach (Button button in mainMenu.GetComponentsInChildren<Button>(true))
            {
                button.gameObject.SetActive(true);
            }
        }
    }
}