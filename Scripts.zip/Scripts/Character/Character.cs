using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace MyGameProject
{
    public abstract class Character : MonoBehaviour
    {
        public float maxHealth = 100f;
        [SerializeField]
        private float currentHealth;
        private State state = State.INGAME;


        void Start()
        {
            currentHealth = maxHealth;
        }

        public float CurrentHealth
        {
            get { return currentHealth; }
            protected set
            {
                if (value <= 0f)
                {
                    currentHealth = 0f;
                }
                else if (currentHealth > maxHealth)
                {
                    currentHealth = maxHealth;
                }
                else
                {
                    currentHealth = value;
                }
            }
        }

        public State StateSetGet
        {
            get { return state; }
            set { state = value; }
        }

        // ����� ��� ��������� �����
        public abstract void TakeDamage(float damage);

        public void CheckHealth()
        {
            UpdateState();
        }

        public bool IsAlive()
        {
            if (StateSetGet == State.INGAME)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public abstract void Heal(float healingAmount);

        public abstract void UpdateState();
    }
}