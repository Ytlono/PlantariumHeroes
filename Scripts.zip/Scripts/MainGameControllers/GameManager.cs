using System.Collections.Generic;
using UnityEngine;

namespace MyGameProject
{
    public class GameManager : MonoBehaviour
    {
        [SerializeField] private Player player; // ������ �� ������
        [SerializeField] private List<Enemy> enemies; // ������ ������ � ����

        private void Start()
        {
            if (player == null)
            {
                player = FindObjectOfType<Player>();
            }

            if (enemies.Count == 0)
            {
                enemies.AddRange(FindObjectsOfType<Enemy>());
            }
        }

        private void Update()
        {
            HandlePlayerState();
        }

        private void HandlePlayerState()
        {
            if (player == null || !player.IsAlive())
            {
                StopEnemiesActions();
            }
            else
            {
                ResumeEnemiesActions();
            }
        }

        private void StopEnemiesActions()
        {
            foreach (var enemy in enemies)
            {
                if (enemy != null && enemy.IsAlive())
                {
                    EnemyController controller = enemy.GetComponent<EnemyController>();
                    if (controller != null)
                    {
                        controller.StopActions(); // ��������� ���� �������� �����
                    }
                }
            }
        }

        private void ResumeEnemiesActions()
        {
            foreach (var enemy in enemies)
            {
                if (enemy != null && enemy.IsAlive())
                {
                    EnemyController controller = enemy.GetComponent<EnemyController>();
                    if (controller != null)
                    {
                        controller.ResumeActions(); // ������������� �������� �����
                    }
                }
            }
        }
    }
}
