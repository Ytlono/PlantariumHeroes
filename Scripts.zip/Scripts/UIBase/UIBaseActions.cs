﻿using MyGameProject;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MyGameProject
{
    public class UIBaseActions
    {
    }
}
